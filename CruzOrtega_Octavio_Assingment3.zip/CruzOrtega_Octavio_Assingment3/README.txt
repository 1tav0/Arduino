Circuit 1:
Overall i struggled figuring out how to determine when the servo motor reached 180 degrees
and return back to 0 to light up the LED since I noticed the delay time was crucial as it seemed to have to be a certain value, since values that 
i tested would either fix it or get it stuck not allowing it to rotate.It would only move 
back and forth rapidly in a specific way not rotating all the way unless specific values were used as the delay value.

Circuit 2:
Circuit 2 was much simpler and I really didnt struggle much except maybe with understanding the question.
I understood that when it was bright and the photoresistor was below the threshold then the LED and buzzer would
 be off and when it was dark and the photoresistor was greater than the threshold then the 
LED and buzzer would both be ON. If it was the other way around this can easily be fixed in my code specifically 
in the if statement.


1. How can you make a servo motor rotate clockwise or 
anti-clockwise(answer in your own language)?

There's atleast two ways i know, one is creating a for loop that goes from 0 degrees
to 360 degrees for clockwise or a for loop from 360 degrees to 0 degrees for counter
clock wise.

2. Below is the output getting printed in serial monitor:
Begin:
0
1
2
3
4
5

5
4
3
2
1
0
End.

Fill the program in the box below:

Void setup(){
	int pos;

	For(pos=0; pos<=5; pos+=1 ){
		servo1.write(pos);
	}
	For(pos=5; pos<=0; pos-=1  ){
		servo1.write(pos);
	}
}


3. Why do we use libraries in Arduino? (Answer in your own language)
Arduino is built in C and in C a library is like a package of different 
functions we can use that are built in within the c language.

4. Answer the following questions after reading the below table.

void setup() {
float a,b;
int result;
Serial.begin(9600);
a = 15.2; b = 27.1;
result = compute(a, b);
Serial.print(result);
}
void loop() {}
int compute(float number1, float number2){
int comp; 
comp = number2 * number1;
return(comp);
}

(Hint: definition of Float data type: Data type for floating-point number is a 
number that has a decimal point. Floating-point numbers are often used to 
approximate the analog and continuous values because they have greater 
resolution than integers.)

a. What will be the output on the serial monitor?
The output will be number2 * number1 
therefore 15.2 * 27.1
output will be 411.92

b. What will be the change if instead of float data type, int 
data type is used in the above program?

The result will be whole number instead of a floating (decimal) number.
15.2 will become 15 and 27.1 will become 27
the result would be 405

5. What is the output of the following?
Int integer = 27;
Integer += 1;
Str string = “27”;
String += 1;

Remember there are two outputs for two segments of the program above.

27 + 1 
= 28

"27" + 1
= "271"

So, output of the code is
28, 271 so letter C.
