/****OCTAVIO CRUZ ORTEGA*****/
/****918512808*****/



Circuit 1:
The most difficult part of this circuit was making the two different tunes work 
in synchronization with the buttons. I struggled with the connections of the buttons
since they did not seem to work and i couldnt figure out why, but upon research on how to connect them, i finally got them to work using a pullup 
resistor connected to each of them. Once i did this the circuit and code worked perfectly.

Circuit 2:
The most difficult part of this circuit once again was the connection of the 
buttons, but upon having done and dealt with buttons connections in the first circuit,
the pull up resistor was the way to go in making all three buttons work perfectly. My code 
is easy to follow and understand and coding the motor driver to go along with the buttons 
was easy to do afterwards.

Circuit 3:
The most difficult  part of this circuit was the final output as I had trouble figuring out exactly 
what would be the best threshold to use for the temperature sensor to trigger
the motor and LED. Overall this was my main difficulty, but upon trial and error and 
using the serial monitor provided in the Arduino IDE i was able to figure out 
the threshold that gave me the best results.

Overall, I really enjoyed struggling in connecting the buttons as it gave me a
great feeling of satisfaction once i got them to work without errors. The second circuit 
was similar to the one we did in class where many of us couldnt get all three buttons to work
but upon practicing this circuit at home, i finally figured out why and all three buttons
worked perfectly the solution was a pullup resistor connected to each button. I made sure to use Serial.println() to print their values in the 
serial monitor and they all gave the expected results everytime. It was great practice 
and helped me understand how to deal with buttons in my circuits to a higher degree. 