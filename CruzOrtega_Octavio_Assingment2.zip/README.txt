Question1:
For this circuit i was not sure if the circuit had to light up each LED one by one 
or in a sequential pattern but since we used a potentiometer it made more sense to 
me that the LEDs had to turn off and on sequentially and increase in speed as the 
potentiometer increased therefore that was my approach.

Question 2:
For question two, i implememented the RGB LED using two ways, one with a created 
function and the other just the original way we have been doing it. Overall this circuit
gave me insight in the powers of the RGB LED and how to properly connected in the circuit board
ranging its values from 0-255 to change which color i was trying to implement.

Quiz section (10 points)

1. Mention the formulas for series and parallel connections for resistors if 
the values of resistors are R1 and R2 and the resulting one is R3
a. Series : R3 = R1 + R2
b. Parallel : 1/R3 = 1/R1 + 1/R2 which can simplify to R3 = (R1xR2)/(R1+R2)

2. Mention the colors for the tolerance strip of a resistor (there are 3 colors)
The colors for the tolerance strip of the resistors i used are:
orange - orange - brown - gold which signify: (3 3 x 10) +- 5% (tolerance) = 330+-5% ohms

3. Why analog values coming out from analog pins ranges from 0-1023?

Arduino boards contain a multichannel, 10-bit analog to digital converter.
This means that it will map input voltages between 0 and the operating voltage(5V)
into integer values between 0 and 1023.

4. What is wrong with the following:
/*Turns on an LED on for one second, then off for one second, repeatedly. 
This example code is in the public domain.*/ 

int led = 13; void setup() 
{ 
	pinMode(led, INPUT);
} 
void loop() 
{ 
	digitalWrite(led, HIGH); 
	delay(1000); 
	digitalWrite(led, LOW); 
	delay(1000);
}

The pinMode(led, INPUT); should initialize the led to OUTPUT.
so it ahouls be pinMode(led,OUTPUT);

5. Before your program code can be sent to the board, it needs to be 
converted into the instructions that can be understood by the board. 
This process is called…..
Compilation. The Arduino IDE converts the high level language into binary code 
that can be understood by the microcontroller.

6. Delay(3000) means….

wait for 3 seconds.

7. What are two basic functions required for coding your Arduino (Redboard) 
board?

loop() and setup()

8. What will be the outcome for the following?
pinMode(9,OUTPUT);
analogWrite(9,63.5);

A square wave generated signal with output voltage of 6.3V

9. How many analog pins are there on the redboard?
From A0-A5 therefore a total of 6 analog pins.


10. Which one of the following commands is used correctly to read the value of a 
pin set as a logic input in Arduino C

digitalWrite();
