For assignment 1 the most difficult part of alternating the LEDs was deciding whether
or not to use an iterative loop. I tried the for loop, but 
i was having difficulties turning off all the LEDs at once, after the first iteration of the
LEDs turning on. Hence i decided to go with the basic way, and made it work.
For the touchdown Zone lights. The logic was pretty straight forward and besides figuring out the best way
to avoid using a lot of jumper cables, i did not encounter any problems.